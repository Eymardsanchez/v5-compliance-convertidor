"""
bancos/estandar_universal.py
─────────────────────────────────────────────────────────────────────────────
Extractor fallback universal para estados de cuenta bancarios mexicanos.

PROPÓSITO
─────────
Se activa en dos casos:
  1. El banco no está registrado en EXTRACTORES ni en _IBM_MAP (banco nuevo,
     desconocido, o institución no bancaria como SOFOM/Fintech).
  2. El extractor específico lanzó una excepción durante la extracción.

ESTRATEGIA DE DETECCIÓN AUTOMÁTICA
─────────────────────────────────────
Fase 1 — Auto-inferencia del formato de fecha
  Se escanean las primeras 120 líneas con contenido para encontrar cuál de los
  8 patrones de fecha conocidos coincide de forma consistente con ≥ 3 líneas
  distintas.  El patrón con más coincidencias gana.

  Patrones soportados (más específico primero para evitar falsos positivos):
    DD-MMM-YYYY  → "15-MAR-2026 PAGO..."      (Santander, genérico)
    DD-MMM-YY    → "05-MAY-26COMPRA..."        (Banorte PFAE)
    DD/MM/YYYY   → "15/05/2026 TRANSFER..."    (genérico)
    DD/MM/YY     → "15/05/26 PAGO..."          (genérico, año 2 dígitos)
    DD/MMM       → "15/MAR SPEI..."            (BBVA — sin año en fecha)
    DD/MM        → "15/05 PAGO..."             (genérico, sin año)
    MMM. DD      → "MAY. 12 DEPOSITO..."       (Inbursa)
    D/DD MMM     → "15 MAY PROVEEDOR..."       (Banbajío, Banamex)

Fase 2 — Inferencia del año
  Si el formato detectado incluye año en la fecha → se extrae directamente.
  Si no → se busca el primer "20XX" en el texto del encabezado (página 1).
  Fallback: año en curso del sistema.

Fase 3 — Activación de sección
  Se reconocen automáticamente los marcadores de saldo inicial usados por
  todos los bancos mexicanos:
    "SALDO ANTERIOR", "SALDO INICIAL", "SALDO FINAL DEL PERIODO ANTERIOR",
    "BALANCE INICIAL".
  Si no se encuentran, la sección se activa en la primera línea que matchee
  la fecha detectada.

LIMITACIONES CONOCIDAS
──────────────────────
• Banamex y Banregio usan coordenadas de columna (x0) para separar CARGO/ABONO
  del SALDO. El fallback usa solo texto lineal: si el monto está en columna
  separada sin separador en el texto plano, quedará como saldo=None hasta que
  la línea de continuación lo complete. Estos bancos SIEMPRE deben preferir
  su extractor nativo.
• HSBC requiere decodificación de fuente Type3 (cid:N); este fallback no la
  hace.  Si se detectan muchos (cid:N) en el texto, el extractor advierte al
  usuario.
• BBVA tiene dos fechas por línea (OPER + LIQ) y un código de 3 letras; el
  fallback capturará solo la primera fecha y tratará el código como parte de
  la descripción (comportamiento degradado pero funcional).
"""

import re
import datetime
import unicodedata
from typing import Optional, Callable

import pdfplumber

from bancos.base import BancoExtractor, Movimiento, InfoCuenta


# ─────────────────────────────────────────────────────────────────────────────
# Constantes compartidas
# ─────────────────────────────────────────────────────────────────────────────

MESES: dict[str, str] = {
    "ENE": "01", "FEB": "02", "MAR": "03", "ABR": "04",
    "MAY": "05", "JUN": "06", "JUL": "07", "AGO": "08",
    "SEP": "09", "OCT": "10", "NOV": "11", "DIC": "12",
}

AMOUNT_RE = re.compile(r"([\d,]+\.\d{2})")

# ── Regex de año en encabezado ────────────────────────────────────────────────
_YEAR_RE = re.compile(r"\b(20\d{2})\b")

# ── Normalización OCR: punto como separador de miles (Banorte PFAE) ───────────
# "296.076.78" → "296,076.78"
_SALDO_PUNTO_MILES = re.compile(r"(\d{1,3})\.(\d{3})\.(\d{2})(?=\s|$)")

# ── Limpieza de glifos (cid:N) ────────────────────────────────────────────────
_CID_RE = re.compile(r"\(cid:\d+\)")

# ── Patrones de fin de sección (universales) ──────────────────────────────────
_FIN_SECCION_RE = re.compile(
    r"TOTAL\s+DE\s+MOVIMIENTOS"
    r"|MENSAJES\s+IMPORTANTES"
    r"|AVISO\s+DE\s+PRIVACIDAD"
    r"|COMPROBANTE\s+FISCAL\s+DIGITAL"
    r"|SALDO\s+FINAL\s+DEL\s+PERIODO(?!\s+ANTERIOR)"
    r"|RESUMEN\s+DE\s+COMISIONES"
    r"|SIGNIFICADO\s+DE\s+ABREVIATURAS"
    r"|INFORMACION\s+RELEVANTE"
    r"|GAT\s+NOMINAL"
    r"|ADVERTENCIAS\s+Y\s+RECOMENDACIONES"
    r"|INVERSION\s+ENLACE\s+NEGOCIOS",
    re.IGNORECASE,
)

# ── Patrones de saldo inicial (activan la sección) ────────────────────────────
_SALDO_INI_RE = re.compile(
    r"SALDO\s+(?:ANTERIOR|INICIAL|FINAL\s+DEL\s+PERIODO\s+ANTERIOR)"
    r"|BALANCE\s+INICIAL",
    re.IGNORECASE,
)

# ── Skip universal: pies de página de instituciones bancarias mexicanas ───────
# (No se filtran líneas de transacciones — solo pie/encabezado institucional)
_SKIP_INSTITUCIONAL_RE = re.compile(
    r"BANCO\s+MERCANTIL\s+DEL\s+NORTE"
    r"|BANCO\s+REGIONAL\s+DE\s+MONTERREY"
    r"|GRUPO\s+FINANCIERO"
    r"|INSTITUCI[ÓO]N\s+DE\s+BANCA\s+M[ÚU]LTIPLE"
    r"|LINEA\s+DIRECTA\s+PARA\s+SU\s+EMPRESA"
    r"|CONSULTAS\s*,\s*RECLAMACIONES"
    r"|(?:^|\s)PAG(?:INA|\.)\s*\d"
    r"|RFC\s+BMN\d|RFC\s+BBV\d|RFC\s+BBA\d",
    re.IGNORECASE,
)

# ─────────────────────────────────────────────────────────────────────────────
# Catálogo de formatos de fecha
# Cada entrada: (nombre, regex, fn_normalizar(match, anio) -> str)
# fn_normalizar devuelve "DD/MM/YYYY" si el año está en la fecha,
#                        "DD/MM"      si el año debe tomarse del encabezado.
# ─────────────────────────────────────────────────────────────────────────────

def _m_dd_mmm_yyyy(m: re.Match, _: str) -> str:
    return f"{m.group(1)}/{MESES.get(m.group(2), m.group(2))}/{m.group(3)}"

def _m_dd_mmm_yy(m: re.Match, _: str) -> str:
    return f"{m.group(1)}/{MESES.get(m.group(2), m.group(2))}/20{m.group(3)}"

def _m_dd_mm_yyyy(m: re.Match, _: str) -> str:
    return f"{m.group(1)}/{m.group(2)}/{m.group(3)}"

def _m_dd_mm_yy(m: re.Match, _: str) -> str:
    return f"{m.group(1)}/{m.group(2)}/20{m.group(3)}"

def _m_dd_mmm_noanio(m: re.Match, anio: str) -> str:
    return f"{m.group(1)}/{MESES.get(m.group(2), m.group(2))}/{anio}"

def _m_dd_mm_noanio(m: re.Match, anio: str) -> str:
    return f"{m.group(1)}/{m.group(2)}/{anio}"

def _m_mmm_dd(m: re.Match, anio: str) -> str:
    return f"{m.group(2).zfill(2)}/{MESES[m.group(1)]}/{anio}"

def _m_d_mmm(m: re.Match, anio: str) -> str:
    return f"{m.group(1).zfill(2)}/{MESES[m.group(2)]}/{anio}"


DATE_CATALOG: list[tuple[str, re.Pattern, bool, Callable]] = [
    # (nombre, regex, año_en_fecha, fn_normalizar)
    # Orden: YYYY antes de YY para evitar capturar los primeros 2 dígitos de 2026
    ("DD-MMM-YYYY",
     re.compile(r"^(\d{2})-([A-Z]{3})-(\d{4})"),
     True,  _m_dd_mmm_yyyy),

    ("DD-MMM-YY",
     re.compile(r"^(\d{2})-([A-Z]{3})-(\d{2})(?!\d)"),
     True,  _m_dd_mmm_yy),

    ("DD/MM/YYYY",
     re.compile(r"^(\d{2})/(\d{2})/(\d{4})"),
     True,  _m_dd_mm_yyyy),

    ("DD/MM/YY",
     re.compile(r"^(\d{2})/(\d{2})/(\d{2})(?!\d)"),
     True,  _m_dd_mm_yy),

    ("DD/MMM",
     re.compile(r"^(\d{2})/(ENE|FEB|MAR|ABR|MAY|JUN|JUL|AGO|SEP|OCT|NOV|DIC)"),
     False, _m_dd_mmm_noanio),

    ("DD/MM",
     re.compile(r"^(\d{2})/(\d{2})(?!/\d)"),
     False, _m_dd_mm_noanio),

    ("MMM. DD",
     re.compile(r"^(ENE|FEB|MAR|ABR|MAY|JUN|JUL|AGO|SEP|OCT|NOV|DIC)\.\s+(\d{1,2})\b"),
     False, _m_mmm_dd),

    ("D/DD MMM",
     re.compile(r"^(\d{1,2})\s+(ENE|FEB|MAR|ABR|MAY|JUN|JUL|AGO|SEP|OCT|NOV|DIC)\b"),
     False, _m_d_mmm),
]


# ─────────────────────────────────────────────────────────────────────────────
# Utilidades
# ─────────────────────────────────────────────────────────────────────────────

def _preprocesar_linea(linea: str) -> str:
    """Limpieza universal antes de parsear."""
    linea = _CID_RE.sub("", linea)                     # quitar glifos (cid:N)
    linea = _SALDO_PUNTO_MILES.sub(                    # normalizar sep miles OCR
        lambda m: f"{m.group(1)},{m.group(2)}.{m.group(3)}", linea
    )
    return linea.strip()


def _sin_acentos(s: str) -> str:
    return "".join(
        c for c in unicodedata.normalize("NFD", s)
        if unicodedata.category(c) != "Mn"
    ).upper()


def _extraer_anio(texto: str) -> str:
    """Extrae el primer año 20XX del texto del encabezado."""
    m = _YEAR_RE.search(texto)
    if m:
        return m.group(1)
    return str(datetime.datetime.now().year)


def _inferir_formato_fecha(lineas: list[str]) -> tuple[re.Pattern, Callable, bool] | None:
    """
    Escanea las primeras `lineas` (ya preprocesadas) y elige el patrón de
    fecha con más coincidencias consistentes (mínimo 2 hits).

    Retorna (regex, fn_normalizar, año_en_fecha) o None si no detecta nada.
    """
    conteos: dict[str, int] = {nombre: 0 for nombre, *_ in DATE_CATALOG}

    for linea in lineas:
        for nombre, pat, _, _ in DATE_CATALOG:
            if pat.match(linea):
                conteos[nombre] += 1
                break  # una línea solo puede matchear un patrón

    # El patrón con más hits que supere el umbral mínimo de 2
    mejor = max(conteos.items(), key=lambda x: x[1])
    if mejor[1] < 2:
        return None

    for nombre, pat, tiene_anio, fn in DATE_CATALOG:
        if nombre == mejor[0]:
            return pat, fn, tiene_anio

    return None


def _verify_by_balance(mov: Movimiento, prev_saldo: Optional[float]) -> None:
    """Corrige DEP/RET por balance tracking (método universal)."""
    if prev_saldo is None or mov.saldo is None:
        return
    amount = (mov.deposito or 0.0) + (mov.retiro or 0.0)
    if amount == 0:
        return
    if abs((prev_saldo + amount) - mov.saldo) < 1.0:
        mov.deposito = amount
        mov.retiro = None
    elif abs((prev_saldo - amount) - mov.saldo) < 1.0:
        mov.retiro = amount
        mov.deposito = None


def _rescatar_montos_de_descripcion(
    mov: Movimiento, prev_saldo: Optional[float]
) -> None:
    """
    BUG-SAFE: cuando _parse_linea no encontró montos (p. ej. en SPEI multilínea
    donde el monto viene al final de la descripción acumulada), intenta rescatar
    los dos últimos amounts de la descripción completa.
    Aplica solo si saldo=None AND retiro=None AND deposito=None.
    """
    if not (mov.saldo is None and mov.retiro is None and mov.deposito is None):
        return
    desc_norm = _SALDO_PUNTO_MILES.sub(
        lambda m: f"{m.group(1)},{m.group(2)}.{m.group(3)}", mov.descripcion
    )
    amts = AMOUNT_RE.findall(desc_norm)
    if len(amts) < 2:
        return
    try:
        amount_val = float(amts[-2].replace(",", ""))
        saldo_val  = float(amts[-1].replace(",", ""))
        mov.saldo  = saldo_val
        if prev_saldo is not None:
            if abs((prev_saldo + amount_val) - saldo_val) < 1.0:
                mov.deposito = amount_val
            elif abs((prev_saldo - amount_val) - saldo_val) < 1.0:
                mov.retiro = amount_val
            else:
                mov.retiro = amount_val      # default si balance no cierra
        else:
            mov.retiro = amount_val
    except (ValueError, IndexError):
        pass


# ─────────────────────────────────────────────────────────────────────────────
# Extractor universal
# ─────────────────────────────────────────────────────────────────────────────

class BancoUniversalExtractor(BancoExtractor):
    """
    Extractor de último recurso para bancos no registrados o cuando el
    extractor específico falla.

    Se instancia con el nombre del banco (si se conoce) para que aparezca
    correctamente en el reporte Excel.
    """

    NOMBRE    = "Universal"
    COLOR_HEX = "5A5A5A"   # gris neutro

    def __init__(self, nombre_banco: str = "Banco Desconocido"):
        self.NOMBRE = nombre_banco

    @classmethod
    def detectar(cls, texto: str) -> bool:
        # El extractor universal no se registra en el detector automático;
        # se instancia explícitamente cuando ningún otro extractor funciona.
        return False

    # ── API principal ─────────────────────────────────────────────────────────

    def extraer(
        self,
        pdf_path: str,
        progress_callback: Optional[Callable[[int, int], None]] = None,
    ) -> tuple[list[Movimiento], InfoCuenta]:

        info = InfoCuenta(banco=self.NOMBRE)
        movimientos: list[Movimiento] = []

        # Extraer TODO el texto del PDF primero para la fase de detección
        paginas_texto: list[str] = []
        with pdfplumber.open(pdf_path) as pdf:
            total = len(pdf.pages)
            for page in pdf.pages:
                texto = page.extract_text(x_tolerance=2, y_tolerance=3) or ""
                paginas_texto.append(texto)

        if not paginas_texto:
            return movimientos, info

        # ── Fase 1: advertir si hay glifos Type3 (HSBC) ──────────────────────
        texto_total = "\n".join(paginas_texto)
        tiene_cid = _CID_RE.search(texto_total)
        if tiene_cid:
            info.periodo = (
                "[ADVERTENCIA] PDF con fuentes Type3 (cid:N). "
                "Para extracción precisa use el extractor HSBC nativo."
            )

        # ── Fase 2: inferir año del encabezado ───────────────────────────────
        anio = _extraer_anio(paginas_texto[0])
        self._parse_encabezado(paginas_texto[0], info)

        # ── Fase 3: auto-detectar formato de fecha ───────────────────────────
        lineas_muestra: list[str] = []
        for txt in paginas_texto[:2]:          # solo primeras 2 páginas para inferir
            for raw in txt.splitlines():
                l = _preprocesar_linea(raw)
                if l:
                    lineas_muestra.append(l)
                if len(lineas_muestra) >= 150:
                    break
            if len(lineas_muestra) >= 150:
                break

        resultado_inferencia = _inferir_formato_fecha(lineas_muestra)
        if resultado_inferencia is None:
            # No se detectó ningún formato de fecha → devolver vacío con nota
            info.periodo = info.periodo or (
                "[ADVERTENCIA] No se detectó formato de fecha en el PDF. "
                "Verifique que sea un estado de cuenta bancario mexicano."
            )
            return movimientos, info

        date_pat, date_fn, anio_en_fecha = resultado_inferencia

        # ── Fase 4: extracción línea a línea ─────────────────────────────────
        current:    Optional[Movimiento] = None
        in_section  = False
        prev_saldo: Optional[float]      = None
        done        = False

        for pnum, raw_text in enumerate(paginas_texto):
            if done:
                break
            if progress_callback:
                progress_callback(pnum + 1, total)

            for raw in raw_text.splitlines():
                linea = _preprocesar_linea(raw)
                if not linea:
                    continue

                linea_up = _sin_acentos(linea)

                # ── Fin de sección ────────────────────────────────────────────
                if in_section and _FIN_SECCION_RE.search(linea_up):
                    if current:
                        _rescatar_montos_de_descripcion(current, prev_saldo)
                        _verify_by_balance(current, prev_saldo)
                        movimientos.append(current)
                        current = None
                    done = True
                    break

                # ── Saldo inicial ─────────────────────────────────────────────
                if _SALDO_INI_RE.search(linea_up) and info.saldo_inicial is None:
                    amts = AMOUNT_RE.findall(linea)
                    if amts:
                        info.saldo_inicial = float(amts[-1].replace(",", ""))
                        prev_saldo = info.saldo_inicial
                        in_section = True
                        continue

                # ── Skip institucional ────────────────────────────────────────
                if _SKIP_INSTITUCIONAL_RE.search(linea_up):
                    continue

                # ── Línea de transacción ──────────────────────────────────────
                m = date_pat.match(linea)
                if m:
                    if not in_section:
                        in_section = True   # primera fecha vista → activar sección

                    if current:
                        _rescatar_montos_de_descripcion(current, prev_saldo)
                        _verify_by_balance(current, prev_saldo)
                        prev_saldo = current.saldo
                        movimientos.append(current)

                    if anio_en_fecha:
                        fecha = date_fn(m, anio)
                    else:
                        fecha = date_fn(m, anio)     # anio viene del encabezado

                    resto   = linea[m.end():]
                    current = self._parse_linea(fecha, resto, prev_saldo)

                # ── Línea de continuación ─────────────────────────────────────
                elif current and in_section:
                    current.descripcion += " | " + linea

            # end for líneas

        # Guardar último movimiento pendiente
        if current:
            _rescatar_montos_de_descripcion(current, prev_saldo)
            _verify_by_balance(current, prev_saldo)
            movimientos.append(current)

        if movimientos:
            info.total_depositos = sum(mv.deposito or 0 for mv in movimientos)
            info.total_retiros   = sum(mv.retiro   or 0 for mv in movimientos)
            info.saldo_final     = movimientos[-1].saldo

        return movimientos, info

    # ── Parseo de línea individual ────────────────────────────────────────────

    def _parse_linea(
        self, fecha: str, resto: str, prev_saldo: Optional[float]
    ) -> Movimiento:
        """
        Parsea el campo de texto que sigue a la fecha.
        Convención universal:
          • ≥ 2 numbers  → penúltimo = monto, último = saldo
          • 1 number     → es el saldo (monto llegará en continuación)
          • 0 numbers    → saldo=None (monto llegará en continuación)
        """
        amounts = AMOUNT_RE.findall(resto)

        saldo:      Optional[float] = None
        amount_val: Optional[float] = None
        desc = resto

        if len(amounts) >= 2:
            amount_val = float(amounts[-2].replace(",", ""))
            saldo      = float(amounts[-1].replace(",", ""))
            last_pos   = resto.rfind(amounts[-2])
            desc       = resto[:last_pos].strip()
        elif len(amounts) == 1:
            saldo    = float(amounts[0].replace(",", ""))
            last_pos = resto.rfind(amounts[0])
            desc     = resto[:last_pos].strip()

        desc = re.sub(r"\s+", " ", desc).strip()

        # Primer token puramente numérico → folio/referencia
        folio = ""
        partes = desc.split(None, 1)
        if partes and re.match(r"^\d+$", partes[0]):
            folio = partes[0]
            desc  = partes[1].strip() if len(partes) > 1 else ""

        mov = Movimiento(fecha=fecha, folio=folio, descripcion=desc, saldo=saldo)
        if amount_val is not None:
            # Asignar como retiro provisionalmente; _verify_by_balance corregirá
            mov.retiro = amount_val
        return mov

    # ── Encabezado ────────────────────────────────────────────────────────────

    def _parse_encabezado(self, texto: str, info: InfoCuenta) -> None:
        for ln in texto.splitlines():
            ln = ln.strip()
            if not ln:
                continue
            # RFC
            if not info.rfc:
                m = re.search(
                    r"R\.?F\.?C\.?\s*[:\-]?\s*([A-Z&]{3,4}\d{6}[A-Z0-9]{3})",
                    ln.upper()
                )
                if m:
                    info.rfc = m.group(1)
            # Período
            if not info.periodo and re.search(
                r"PERIODO|PER[IÍ]ODO|ESTADO\s+DE\s+CUENTA", ln.upper()
            ):
                info.periodo = ln
            # CLABE
            if not info.clabe:
                m = re.search(r"\b(\d{18})\b", ln)
                if m:
                    info.clabe = m.group(1)
            # Número de cuenta (10-16 dígitos, no CLABE)
            if not info.numero_cuenta:
                m = re.search(r"\b(\d{10,16})\b", ln)
                if m and len(m.group(1)) != 18:
                    info.numero_cuenta = m.group(1)
