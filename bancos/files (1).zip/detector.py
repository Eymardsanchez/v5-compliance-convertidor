"""
Detecta automáticamente qué banco corresponde a un PDF y retorna el extractor correcto.
Para agregar un banco nuevo: crear su módulo en /bancos/ y registrarlo en EXTRACTORES
y en _IBM_MAP.

Estrategia de detección (tres fases):
  1ª PRIORIDAD — Ancla "Institución de Banca Múltiple":
     En el pie/encabezado de cada página de un estado de cuenta mexicano siempre
     aparece la leyenda:
         <NOMBRE BANCO>  S.A.,  Institución de Banca Múltiple  <GRUPO> …
     Se busca la palabra pivote "INSTITUC…" y se toma todo lo que está a su
     IZQUIERDA en la misma línea: eso es el nombre oficial del banco.
     Esta estrategia es inmune a falsos positivos por SPEIs/transferencias a
     otros bancos que aparezcan en el cuerpo de las transacciones.

  2ª PRIORIDAD — Fallback por keywords en texto completo:
     Si la frase IBM no se encontró (PDF escaneado, tipo de fuente incompatible,
     Inbursa que usa su propia leyenda, HSBC con fuentes Type3), se corre cada
     extractor.detectar() en el orden de EXTRACTORES.

  3ª PRIORIDAD (NUEVA) — Fallback universal BancoUniversalExtractor:
     Si ningún extractor específico detecta el banco, se instancia
     BancoUniversalExtractor con el nombre inferido del PDF (o "Banco Desconocido").
     Este extractor auto-detecta el formato de fecha y extrae todos los movimientos
     de forma degradada pero funcional.

Además, extraer_con_fallback() envuelve la extracción con manejo de excepciones:
     si el extractor específico falla en tiempo de ejecución, se reintenta
     automáticamente con BancoUniversalExtractor.
"""

import re
import threading
import pdfplumber
from bancos.base import BancoExtractor, Movimiento, InfoCuenta
from bancos.estandar_universal import BancoUniversalExtractor

# ── Lock global compartido ────────────────────────────────────────────────────
# pdfminer mantiene caché de fuentes a nivel de proceso. Serializar TODA apertura
# de PDF (detección y extracción) evita corrupción cuando hay múltiples hilos.
# Se usa RLock (reentrant) para que el mismo hilo pueda adquirirlo varias veces
# sin deadlock (p.ej. cuando _detect() adquiere el lock y llama a detectar_banco
# que también lo adquiere internamente).
PDF_LOCK = threading.RLock()

from bancos.santander import SantanderExtractor
from bancos.bbva      import BBVAExtractor
from bancos.banregio  import BanregioExtractor
from bancos.inbursa   import InbursaExtractor
from bancos.banorte   import BanorteExtractor
from bancos.banbajio  import BanbajioExtractor
from bancos.hsbc      import HSBCExtractor
from bancos.banamex   import BanamexExtractor
from bancos.konfio    import KonfioExtractor

# ── Registro de extractores (fallback por keywords) ───────────────────────────
# Sólo se usa si la estrategia IBM no logra identificar el banco.
# ORDEN: más específicos primero para evitar falsos positivos.
# Konfio va primero: es SOFOM (sin leyenda IBM) y usa "KONFIO"/"RED AMIGO DAL"
# que son tokens muy específicos — no confunden con ningún banco tradicional.
EXTRACTORES: list[type[BancoExtractor]] = [
    KonfioExtractor,     # "KONFIO" / "RED AMIGO DAL" — SOFOM TC, sin IBM
    InbursaExtractor,    # "CLIENTE INBURSA" + "BALANCE INICIAL" — muy específico
    BanregioExtractor,   # "BANREGIO" / "BANCO REGIONAL"
    BanorteExtractor,    # "BANCO MERCANTIL DEL NORTE" / "ENLACE NEGOCIOS/GLOBAL"
    BanbajioExtractor,   # "BANBAJIO" / "BANCO DEL BAJIO"
    SantanderExtractor,  # "BANCO SANTANDER" / "SANTANDER MEXICO"
    BBVAExtractor,       # "BBVA" — antes que Banamex para evitar falso positivo
    BanamexExtractor,    # "BANAMEX" / "CITIBANAMEX" — sólo busca en encabezado
    HSBCExtractor,       # (cid: en texto crudo — al final)
]

# ── Mapa IBM: prefijos del nombre oficial → extractor ─────────────────────────
# Se compara contra el texto normalizado (mayúsculas, sin acentos) que aparece
# a la izquierda de "INSTITUC…" en el pie de página.
# Ordenado de más específico a más general para evitar coincidencias parciales.
_IBM_MAP: list[tuple[str, type[BancoExtractor]]] = [
    # Banamex  (antes que variante genérica "BANCO NACIONAL")
    ("BANCO NACIONAL DE MEXICO",   BanamexExtractor),
    ("CITIBANAMEX",                BanamexExtractor),
    ("BANAMEX",                    BanamexExtractor),
    # Banorte  (razón social completa — evita confusión con "BANCO" genérico)
    ("BANCO MERCANTIL DEL NORTE",  BanorteExtractor),
    ("BANORTE",                    BanorteExtractor),
    # Banregio
    ("BANCO REGIONAL DE MONTERREY", BanregioExtractor),
    ("BANCO REGIONAL",             BanregioExtractor),
    ("BANREGIO",                   BanregioExtractor),
    # Banbajío
    ("BANCO DEL BAJIO",            BanbajioExtractor),
    ("BANBAJIO",                   BanbajioExtractor),
    # Santander
    ("BANCO SANTANDER MEXICO",     SantanderExtractor),
    ("BANCO SANTANDER",            SantanderExtractor),
    ("SANTANDER",                  SantanderExtractor),
    # BBVA  (razón social: "BBVA MEXICO, S.A., IBM…")
    ("BBVA",                       BBVAExtractor),
    # HSBC
    ("HSBC MEXICO",                HSBCExtractor),
    ("HSBC",                       HSBCExtractor),
    # Inbursa  (algunos formatos usan IBM aunque Inbursa también tiene su leyenda propia)
    ("BANCO INBURSA",              InbursaExtractor),
    ("INBURSA",                    InbursaExtractor),
]


# ── Helpers estrategia IBM ────────────────────────────────────────────────────

def _norm(s: str) -> str:
    """Normaliza a mayúsculas y reemplaza vocales acentuadas y Ñ."""
    tr = str.maketrans(
        "ÁÉÍÓÚÜÑáéíóúüñ",
        "AEIOUUNaeiouun"
    )
    return s.upper().translate(tr)


def _detectar_por_ibm(
    page_words: list[list[dict]],
) -> type[BancoExtractor] | None:
    """
    Recorre las palabras extraídas de cada página buscando el pivote IBM.
    Retorna la CLASE del extractor (no una instancia) o None si no lo encuentra.

    Algoritmo:
      1. Buscar cualquier palabra cuyo texto normalizado empiece con "INSTITUC".
      2. Verificar que en la misma línea (y ± 3 pt) aparezcan "BANCA" y "MULTIPLE"
         (descarta coincidencias espurias con otras palabras que empiecen con "INSTITUC").
      3. Recolectar todas las palabras de esa línea cuya x0 sea MENOR que la del
         pivote (= el nombre del banco) y unirlas en un string normalizado.
      4. Buscar ese string en _IBM_MAP usando startswith para tolerancia a sufijos
         como "S.A.", comas, abreviaciones de grupo financiero, etc.
    """
    for words in page_words:
        if not words:
            continue

        for w in words:
            if not _norm(w["text"]).startswith("INSTITUC"):
                continue

            # Palabras en la misma línea (tolerancia ±3 pt en centro vertical)
            y_center = (w["top"] + w["bottom"]) / 2
            same_line = [
                x for x in words
                if abs((x["top"] + x["bottom"]) / 2 - y_center) < 3
            ]
            line_norm = " ".join(_norm(x["text"]) for x in same_line)

            # Confirmar que es realmente la leyenda IBM
            if "BANCA" not in line_norm or "MULTIPLE" not in line_norm:
                continue

            # Palabras a la IZQUIERDA del pivote (x0 < pivote_x0 con margen de 1 pt)
            pivot_x = w["x0"]
            left_words = sorted(
                [x for x in same_line if x["x0"] < pivot_x - 1],
                key=lambda x: x["x0"],
            )
            if not left_words:
                continue

            bank_raw = " ".join(_norm(x["text"]) for x in left_words)
            # Limpiar comas, puntos, "S.A." y variantes al final
            # (p. ej. "BBVA MEXICO, S.A.," → "BBVA MEXICO")
            bank_clean = re.sub(
                r"[\s,\.]*S\.?\s*A\.?[\s,\.]*$",
                "",
                bank_raw,
            ).strip(" ,.")

            # Buscar en el mapa (el más específico primero)
            for prefix, cls in _IBM_MAP:
                if bank_clean.startswith(prefix):
                    return cls

            # Mapa no reconoce el banco — seguir con fallback
            # (No retornamos None aquí; puede haber más páginas por revisar)

    return None


def _inferir_nombre_banco(page_texts: list[str]) -> str:
    """
    Intenta inferir el nombre del banco del texto del PDF cuando no
    está en el mapa IBM.  Busca la leyenda "Institución de Banca Múltiple"
    y extrae las palabras que la preceden como nombre del banco.

    Retorna "Banco Desconocido" si no puede inferirlo.
    """
    IBM_TEXT_RE = re.compile(
        r"([A-Z][A-Za-záéíóúüñÁÉÍÓÚÜÑ ,\.]+?)\s+"
        r"S\.?\s*A\.?\s*,?\s*[Ii]nstituci[oó]n\s+de\s+[Bb]anca\s+[Mm][úu]ltiple",
        re.IGNORECASE,
    )
    for txt in page_texts:
        m = IBM_TEXT_RE.search(txt)
        if m:
            nombre = m.group(1).strip(" .,").title()
            if nombre:
                return nombre
    return "Banco Desconocido"


# ── API pública ───────────────────────────────────────────────────────────────

def detectar_banco(pdf_path: str) -> BancoExtractor:
    """
    Lee las primeras páginas del PDF y retorna una instancia del extractor correcto.

    GARANTÍA: nunca retorna None.
    Si ningún extractor específico reconoce el banco, retorna una instancia de
    BancoUniversalExtractor con el nombre inferido del PDF.

    Serializado con PDF_LOCK para evitar corrupción del caché global de pdfminer.
    """
    try:
        with PDF_LOCK:
            with pdfplumber.open(pdf_path) as pdf:
                # 4 páginas: BBVA tiene la página 1 como imagen y el encabezado
                # real en pág. 2; 4 páginas garantizan cubrir ese caso.
                sample_pages = min(4, len(pdf.pages))
                page_words = []
                page_texts = []
                for i in range(sample_pages):
                    page = pdf.pages[i]
                    page_words.append(page.extract_words() or [])
                    page_texts.append(page.extract_text() or "")
    except Exception:
        # Si ni siquiera se puede abrir el PDF, retornar extractor universal vacío
        return BancoUniversalExtractor("Banco Desconocido")

    # ── Estrategia 1: ancla "Institución de Banca Múltiple" ──────────────────
    cls = _detectar_por_ibm(page_words)
    if cls is not None:
        return cls()

    # ── Estrategia 2: fallback por keywords en texto ──────────────────────────
    texto_upper = "\n".join(page_texts).upper()
    for cls in EXTRACTORES:
        if cls.detectar(texto_upper):
            return cls()

    # ── Estrategia 3: fallback universal ─────────────────────────────────────
    # Ningún extractor específico reconoció el banco.
    # Intentar inferir el nombre del banco del texto del PDF.
    nombre_banco = _inferir_nombre_banco(page_texts)
    return BancoUniversalExtractor(nombre_banco)


def banco_nombre(pdf_path: str) -> str:
    """Retorna el nombre del banco detectado ('Banco Desconocido' si no se reconoce)."""
    extractor = detectar_banco(pdf_path)
    return extractor.NOMBRE


def extraer_con_fallback(
    pdf_path: str,
    progress_callback=None,
) -> tuple[list[Movimiento], InfoCuenta, str, bool]:
    """
    Detecta el banco, extrae los movimientos y aplica fallback automático
    si el extractor específico lanza una excepción en tiempo de ejecución.

    Retorna:
        movimientos    : list[Movimiento]
        info           : InfoCuenta
        extractor_usado: str   — nombre del extractor que produjo el resultado
        usó_fallback   : bool  — True si se usó BancoUniversalExtractor en lugar
                                 del específico

    Casos de uso:
        movs, info, extractor, fallback = extraer_con_fallback("estado.pdf")
        if fallback:
            print(f"⚠ Extractor específico falló. Se usó el extractor universal.")
        print(f"Banco detectado: {info.banco} ({len(movs)} movimientos)")
    """
    extractor = detectar_banco(pdf_path)
    es_universal = isinstance(extractor, BancoUniversalExtractor)

    try:
        movimientos, info = extractor.extraer(pdf_path, progress_callback)
        return movimientos, info, extractor.NOMBRE, es_universal

    except Exception as exc:
        if es_universal:
            # El universal también falló → retornar vacío con nota
            info = InfoCuenta(
                banco=extractor.NOMBRE,
                periodo=f"[ERROR] Extracción fallida: {exc}",
            )
            return [], info, extractor.NOMBRE, True

        # El extractor específico falló → reintentar con el universal
        nombre_banco = extractor.NOMBRE
        universal = BancoUniversalExtractor(nombre_banco)
        try:
            movimientos, info = universal.extraer(pdf_path, progress_callback)
            # Agregar nota al período indicando que se usó fallback
            nota = f"[FALLBACK] Extractor {nombre_banco} falló: {exc}"
            info.periodo = (info.periodo or "") + " | " + nota if info.periodo else nota
            return movimientos, info, universal.NOMBRE, True
        except Exception as exc2:
            info = InfoCuenta(
                banco=nombre_banco,
                periodo=f"[ERROR] Extracción fallida con {nombre_banco} y Universal: {exc2}",
            )
            return [], info, "Universal", True
